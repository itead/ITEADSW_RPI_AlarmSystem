#
# GPIO PIN NAME for BOARD_RASPBERRY_PI_RV2
#
GPIO2    =   3 
GPIO3    =   5 
GPIO4    =   7 
GPIO14   =   8 
GPIO15   =   10
GPIO17   =   11
GPIO18   =   12
GPIO27   =   13
GPIO22   =   15
GPIO23   =   16
GPIO24   =   18
GPIO10   =   19
GPIO9    =   21
GPIO25   =   22
GPIO11   =   23
GPIO8    =   24
GPIO7    =   26
GPIO28   =   29
GPIO29   =   30
GPIO30   =   31
GPIO31   =   32
