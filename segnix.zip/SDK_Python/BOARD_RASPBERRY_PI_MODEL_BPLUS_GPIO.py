#
# GPIO PIN NAME for BOARD_RASPBERRY_PI_MODEL_BPLUS
#
GPIO2    =   3 
GPIO3    =   5 
GPIO4    =   7 
GPIO14   =   8 
GPIO15   =   10
GPIO17   =   11
GPIO18   =   12
GPIO27   =   13
GPIO22   =   15
GPIO23   =   16
GPIO24   =   18
GPIO10   =   19
GPIO9    =   21
GPIO25   =   22
GPIO11   =   23
GPIO8    =   24
GPIO7    =   26
GPIO5    =   27
GPIO6    =   28
GPIO12   =   29
GPIO13   =   30
GPIO16   =   31
GPIO19   =   32
GPIO20   =   33
GPIO21   =   34
GPIO26   =   35
