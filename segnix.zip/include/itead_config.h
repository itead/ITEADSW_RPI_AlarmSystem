#ifndef __ITEAD_CONFIG_H__
#define __ITEAD_CONFIG_H__
#define BOARD_RASPBERRY_PI_MODEL_BPLUS
#endif
