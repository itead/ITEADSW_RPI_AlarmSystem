#! /user/bin/env python
from iteadsdk import *
result = analogRead(AIN0)
print result
