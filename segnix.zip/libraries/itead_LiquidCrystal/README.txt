Declaration
===========

the files within this directory is copied from arduino-1.0.5/libraries/LiquidCrystal
and modified by Wu Pengfei<pengfei.wu@itead.cc> to be compitable with IteadOS 
SDK and products of ITEAD Intelligent Systems Co.,Ltd.(http://imall.iteadstudio.com/).

LICENSE
=======

license.txt within this directory is a copy of Arduino IDE Source License. 
All right reserved by Arduino.
