This is a our graphics core library, for all our displays. We'll be adapting all the
existing libaries to use this core to make updating, support and upgrading easier!

At this time, only the SSD1306 library uses it - but we'll be adding more!
    https://github.com/adafruit/Adafruit_SSD1306

Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Written by Limor Fried/Ladyada  for Adafruit Industries.  
BSD license, check license.txt for more information
All text above must be included in any redistribution

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder Adafruit_GFX. Check that the Adafruit_GFX folder contains Adafruit_GFX.cpp and Adafruit_GFX.h

Place the Adafruit_GFX library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.

MODIFIED BY !
Desc: This lib is transplanted to itead sdk by Wu Pengfei.
Date: 2014.3.31
Email: pengfei.wu@itead.cc