# IoTgo Device Library Help

## Documentation

Online API documentation can be reached at <http://docs.iteadstudio.com/IoTgo-ino/>.

More about IoTgo open source cloud platform at https://github.com/itead/IoTgo-Platform.

## How to get started

On the homepage of API documentation, the tabs of Modules, Classes and Examples 
will be useful for developers of Segnix and Arduino. 

# Author

  - Author: Wu Pengfei(pengfei.wu@itead.cc)
  - Date: 11/20/2014 6:27:43 PM 


-------------------------------------------------------------------------------

# The End!

-------------------------------------------------------------------------------
